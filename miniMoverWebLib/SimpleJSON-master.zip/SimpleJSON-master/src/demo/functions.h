// The functions available, 1 single header to make things easier

// The print out function
void print_out(const wchar_t *output);

// Example functions
void example1();
void example2();
void example3();
void example4();

// Test case runner
void run_tests();
